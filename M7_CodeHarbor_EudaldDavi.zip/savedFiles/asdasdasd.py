def func():
    print()